CHANGELOG
=========

## Version 1.0.0-RC1
_2016-03-24_
- **[IMPROVEMENTS]** : Add Readme.txt for wordpress repo and the icon image.
- **[IMPROVEMENTS]** : Updating documentation.
- **[FEATURES]** : Initial features.
